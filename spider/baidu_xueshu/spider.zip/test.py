import re

text="ESD(静电放电)引起IC(集成电路)产品失效已占到IC产品失效的40%,它已成为影响集成电路可靠性的一项重要因素。因此,要使芯片具有高的质量和可靠性就必须解决ESD问题《西安电子科技大学》"
publish_name = re.search(r'《.*》', text)
print(publish_name.group())