#!/usr/bin/env python

# -*- encoding: utf-8 -*-

'''
@Author  :   {lif54334}

@Software:   PyCharm

@File    :   spider_test1.py

@Time    :   2018/7/11 10:26

@Desc    :

'''
import requests

proxy = {
    '120.77.254.116:3128'

}
prox = {
    'http': 'http://' + proxy,
    'https': 'https://' + proxy,
}
head = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
    "Connection":"keep-alive",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language":"zh-CN,zh;q=0.8"
}
url = 'https://www.baidu.com'
try:
    response = requests.get(url,proxies = prox,headers = head)
    print('success'+response.text)
except requests.exceptions.ConnectionError as e:
    print('errpr'+e.args)